#Code and data from the article "Black hole information turbulence and the Hubble tension"
#Copyright (C) 2025  Juan Luis Cabrera Fernández

#This code is licensed under the terms of the Attribution-NonCommercial-ShareAlike 4.0 International - Creative Commons licence (CC BY-NC-SA 4.0). 
#https://creativecommons.org/licenses/by-nc-sa/4.0/deed.en

# darkcolored() calculate the number of zero and non-zero coefficients given by the generation function at Cabrera, Gutierrez & Marquez CSF 146 110876 2021 Equation 50. Note that at each generation the space growths as 3^g thus for normalization porpouses the iteration always goes from g=3 till reaching a maximum g taking care of the maximum dimension generated (d). This is repeated until reaching g_end. A similar procedure must be followed to determine the -5/3 power law. 
#  used intensity and bias parameters a and b SHOULD BE
# a = 0.085
# b = 1.9375 - 0.0225 to reproduce the results of the submitted paper and  to be at r_H = 2
# gend is the total number of generations

function darkcolored(a,b,gend)
    VERBOSE = 0
# this version is restricted to the deterministic code
    deterministic = 1 #depreciated now 
# defining NUMBER OF GENERATIONS. gi IS ALWAYS 3
    gi = 3

# useful simple operations
    BETA = ( (a/2) + b )
    ALPHA =  ( 1.0 - (1.0/BETA) ) 

    BETA2 = BETA*BETA
    ALPHA2 = ALPHA*ALPHA
    BETA4= BETA2*BETA2
# intensity factors
    f22 = (1 + (BETA2 * ALPHA2))        # inner order 2 term (for the main order 2 term)
    f12 = 0.0                           # inner linear term
    f02 = BETA2*( 1 + ALPHA2*BETA2 )    # inner independent term

    f21 = -2.0*ALPHA*BETA2              # same (for the main linear term)
    f11 = 0.0
    f01 = 0.0

    f20 = BETA4*ALPHA2                  # same (for the main independent term)
    f10 = 0.0
    f00 = 0.0

    C2 = 0
    r = a + b
    println("darkcolored(): deterministic, one realization")
    println("darkcolored() ....... a: ", a, " b: ", b, " r= a + b : ",r)
    println("darkcolored() ....... Beta: ", BETA, " Alpha: ", ALPHA)
    println("darkcolored() ....... gi: ", gi, " gend: ", gend)

# first generation
    g = gi
# *output vector dimension: 
# TOTAL number of points to be displayed. AQUI SE DEFINE LA DIMENSION(g)
    d = 3^gend  #output vector dimension: 
#TOTAL number of points to be displayed. AQUI SE DEFINE LA DIMENSION(g)
    println(" #output vector dimension: d: ", d)
# Must be integer
#typeof(d)

#######################################################
# Initializing arrays
# Array for the 3 initial values
    fi = zeros(1,3);
# Array for 9 initial values
    f = zeros(1,9);

# Auxiliary arrays
#l0 = np.zeros(d)
    l1 = zeros(1,d);

#Energy totals by generation. Two 1st generations
    e = zeros(1,gend);
    l_size = zeros(1,gend) #  para almacener el número de elementos no nulos en cada generación - non zero elements on each realization

# colored energy #counting 
    cec = zeros(Int64,gend);
# background energy #counting
    bec = zeros(Int64,gend);

#    delta = zeros(1,gend); # depreciated

#    println("Se han definido los vectores:")
#    println("e : Energy totals by generation")
#    println("l_size : Número de elementos no nulos en cada generación")
#    println("cec : coloured energy counting")
#    println("bec : background energy counting")
    
####################################
    r1 = r;
# NOTE: we will use always r1^2 
    r1 = r1*r1; #square
    k=0;
################################
# Generating the 3 initial values: s=1
    fi[1] = 1.0+(ALPHA2*BETA2) 
    fi[2] = 0.0;
    fi[3] = BETA2;

# Comenzamos calculando los 9 coeficientes de la segunda generación 
# (equivalente a una division del intervalo unidad en segmentos de 1/3^2=1/9 (s=2))
# 9 values for the second generation (s=2, 3^2=9)
# Initializing f[]
    f[1] = f22 * r1;
    f[2] = f12;
    f[3] = f02;
      
    f[4] = f21 * r1;
    f[5] = f11;
    f[6] = f01
      
    f[7] = f20 * r1;
    f[8] = f10;
    f[9] = f00;
    

# fractal array is only used to store first two rows. Inputs layers.
    fractal = zeros(2,d); # En la posición gdet almacenamos la capa de entrada (input layer) que 
# array for fractal    
#####################################
# Llenando la 1ra fila del fractal : row = s-1 .  First row
    bias=d/3
    j=1
    for i=1:d
        if i < bias
            fractal[1,i] = fi[j]
        else
            j += 1
            fractal[1,i] = fi[j]
            bias=bias+bias
        end
    end
#fractal
################################3    
# Llenando la 2da fila del fractal. 2nd row
    s=2
    bias = convert(UInt32, d/(3^s))

    step = bias

    j = 1
    for i=1:d
        if i < bias
            fractal[2,i] = f[j]
        else
            j += 1
            if j < 10 fractal[2,i] = f[j] end
            bias=bias+step
        end
    end
#####################################
# Energy by level, first two levels
    for i=1:2
        e[i] = sum( abs.(fractal[i,:]) )
        l_size[i] = nz = count(!iszero, fractal[i,:])
    end
###################################


# first two values of cec and bec    
#    de = 1/size(fractal)[2]
#    println("Total number of energy levels : ",size(fractal)[2],"; diferencial de energía : de : ",de) # depreciated

    cec[1] = count(!iszero, fi); # Diferent from cero
    cec[2] = count(!iszero, f);

    bec[1] = size(fi)[2] - cec[1];
    bec[2] = size(f)[2] - cec[2];

####################################

# El siguiente paso corresponde a calcular 27 coeficientes correspondientes 
# a la división del intervalo unidad en segmentos de 1/3^3=1/27. 
# Por ello el bias inicial responde a la relación bias=3^send/3^s cuando s=3. 
# esto nos permite movernos entre segmentos contiguos, incrementando el bias 
# en pasos de bias cuando se llega a su frontera. 

#    println("La cascada original ocurre en los coeficientes. La construcción de la cascada")
#    println("sobre el intervalo unidad corresponde a un artificio que se acerca a la evolución")
#    println("de los coeficientes sólo en el límite g->infty. Con el fin de obtener el escalamiento")
#    println("de Kolmogorov es importante realizar el cálculo con apego a la evolución de los")
#    println("coeficientes, lo cual significa que la dimensión del arreglo que los almacena")
#    println("depende de la generación")

#No uso las dos primeras posiciones que corresponderían a las condiciones iniciales (g=0,1)

    for g = gi:gend #+1 # LAZO PRINCIPAL SOBRE g - MAIN LOOP OVER g
        if VERBOSE==1 println("LAZO PRINCIPAL SOBRE g:  gi: ", gi," gend : ",gend," g : ",g) end
# Generaciones subsiguientes, contruidas sobre un segmento de d =  power(3, g) puntos -
# Next generations, built on a segment with  d =  power(3, g) points
# TOTAL number of points to be displayed. AQUI SE DEFINE LA DIMENSION(g)
        d = 3^g  #output vector dimension: 
#        delta[g] = 1/d # depreciated
#        de = delta[g] #depreciated
        if VERBOSE==1 println(" ....HERE ... g : ",g," output vector dimension: d : ",d) end
# dimensión de la recta soporte de la generación final. Depende de g
        l1 = zeros(1,d)
        l0 = zeros(1,d)

        ss = 2
        estebias = convert(UInt32, d/(3^ss))
        step = estebias

# Llenando l0 - l0 filling
        j = 1
        for i=1:d
            if i <=estebias
                l0[i] = f[j]
            else
                if j<9 # si hemos llegado a f[9] estamos terminando de rellenar - if at f[9] we finished filling
                    j = j+1
                    l0[i] = f[j]
                    estebias = estebias + step
                end
            end
            if VERBOSE==1 
                println("Llenando l0: i : ", i," j : ",j, " estebias : ", estebias," l0[i] : ",l0[i]) 
            end
        end
#################
        for s = 3:g #Sub-lazo SOBRE GENERACIONES: Llegamos hasta g / LAZO INTERNO - subloop over generations: going till g
            if VERBOSE==1 println("... ... LAZO INTERNO SOBRE GENERACIONES: entrando s : ",s," g final: ",g," step : ",step) end
            order = 2 #el grado del polinomio decrece desde 2 hasta 0 y vuelve al valor 2 -> 0 - polynomial degree decreases from 2 to 0 and backs to 2->0
            m = 1
            bias2 = convert(UInt32,  d/(3^s) )
            println("Generation: ", s," bias2: ",bias2)
            n = 0    #IMPORTANT
            bias = 1 #IMPORTANT
            if VERBOSE == 1 println("bias : ", bias," bias2 : ",bias2) end
            if VERBOSE == 1 println(" n : ",n," bias +  (bias2*n) : ",bias +  (bias2*n)) end
#### Lazo sobre i principal - loop over i#############################    
            flag = 1
            for i = 1:d # barremos toda la dimension del arreglo / LAZO SOBRE DIMENSION - over all the array dimension
                if i == bias +  (bias2*n)
                    n = n + 1 #si alcanzamos la frontera de un subintervalo pasamos al otro coeficiente - if reaching an subinterval boundary goes to next coefficient 
                    if VERBOSE == 1 println(" ... Frontera de un subintervalo: pasamos al coeficiente siguiente") end
                end
                
                if n == 10 # si llegamos a un valor de n fuera de rango (no puede exceder 9) - if we reach n of range (can't exceed 9)
                    n = 1    # volvemos al principio - start again
                    bias = i # y se asigna el valor del indice como bias de subdivision del segmento - and index is assigned to the bias of segment subdiv                     
                    order = order - 1 #se reduce el grado del polinomio una unidad - polynomial degree reduced by one
 
                    if order == -1  order = 2 end #si se supera grado 0 se restablece grado 2 - if degree falls bellow 0 degree 2 is restated
                end

# se calcula el coeficiente dependiendo de la posición en el arreglo (i) y del segmento (n) - the coefficient value depending on its position in the array (i) and segment (n)
                if n == 1
                    C2 = l0[i] #El mismo valor de la generación anterior en la posición i - same value as in previous generation at position i
                    l1[i] =  C2*r*r
                elseif n == 2 
                    l1[i] = 0.0;
                elseif n == 3 
                    l1[i] =  BETA2*C2*r*r; #C2 tambien se usa aquí
                elseif n == 4 
                    l1[i] =  -order*ALPHA*BETA2*C2*r; #y aquí
                elseif n == 5 
                    l1[i] =  0;
                elseif n == 6 
                    l1[i] =  0;
                elseif n == 7 
                    l1[i] =  BETA2*ALPHA2*l0[i]; #El mismo valor de la generación anterior en la posición i (C0)
                elseif n == 8 
                    l1[i] =  0;
                elseif n == 9 
                    l1[i] =  0;
                end
            end # fin barrido hasta d
#### Fin del lazo sobre i principal #######################  
            for i=1:d  l0[i] = l1[i] end

            if VERBOSE == 1
                println("... ... LAZO INTERNO SOBRE GENERACIONES: saliendo s: ",s)
                println("Generation: ", s," bias2: ",bias2)
            end
    end # Fin barrido SOBRE s hasta g - End loop over s till g

    println("..................................................... End g: ", g)   

# Cual es la suma de sus valores absolutos - Adding absolute values
    e[g] = sum(abs.(l1))
    if VERBOSE == 1 println("g: ", g, " e[g] : ",e[g]) end

# nz : count nonzero coeficients 
    nz = count(!iszero, l1) #how many non cero
    l_size[g] = nz # store as function of g

    if VERBOSE == 1 println("......................... g: ", g, " N valores no nulos : l_size[g] : ",l_size[g]) end
#    if VERBOSE == 1 println("......................... g: ", g, " de : ",delta[g]) end
# cec: colored non zero; bec: background zero values         
    cec[g] = nz 
    bec[g] = (d - nz)
        
    println(" ")
    println("Number of non-zero values: N colored : ", cec[g] )
    println("Number of zero values : N background : ",bec[g])
    
end # FIN LAZO PRINCIPAL SOBRE g hasta gend

println("darkcolored(): returning  l_size, e, cec, bec and exiting .............")




    delta = nothing
    l1 = nothing
    fi= nothing
    f = nothing
    fractal = nothing

    println(" cec: valores no nulos; bec: valores nulos")
    return l_size, e, cec, bec
    
end
