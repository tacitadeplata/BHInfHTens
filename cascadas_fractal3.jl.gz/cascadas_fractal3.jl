#Code and data from the article "Black hole information turbulence and the Hubble tension"
#Copyright (C) 2025  Juan Luis Cabrera Fernández

#This code is licensed under the terms of the Attribution-NonCommercial-ShareAlike 4.0 International - Creative Commons licence (CC BY-NC-SA 4.0). 
#https://creativecommons.org/licenses/by-nc-sa/4.0/deed.en

# @ Juan Luis Cabrera Fernández - NOT FOR DISTRIBUTION
# cascadas_fractal() calculates the fractal figure: given a final generation g_end it starts at g=3 and evaluate the coefficients following the generation function at Cabrera, Gutierrez & Marquez CSF 146 110876 2021 Equation 50. 
#  intensity and bias parameters a and b SHOULD BE
# a = 0.085
# b = 1.9375 - 0.0225
# to be at r_H = 2
# gend is the total number of generations

# probably dirty

function cascadas_fractal(a,b,gend)

#function cascadas_fractal(a,b,gend). Simplified deterministic version with no noise  

#290224: Muy Descafeinado de  de function cascadas_powerLaw_statistics5(a,b,randomType,vsigma,vmean,gend,nrt)

    VERBOSE = 0
  
    println(" ")
    println("cascadas_fractal(a,b,gend) : calculates the fractal cascade :")
    println(" ")
    println("gend is the total number of generations")
    println(" ")

# Cleaning memory in case of repeating running - Limpiamos la memoria en caso de corridas repetidas
    fractal = nothing
    GC.gc()
    GC.gc()

    d = 3^gend # Final space dimension
    fractal = zeros(gend,d); # Fractal
    
    gi = 3 # ALWAYS initial g

# useful simple operations - PARAMETERS ALPHA and BETA as in the paper
    BETA = ( (a/2) + b )
    ALPHA =  ( 1.0 - (1.0/BETA) ) 

    BETA2 = BETA*BETA
    ALPHA2 = ALPHA*ALPHA
    BETA4= BETA2*BETA2

# intensity factors. for the initial conditions
    f22 = (1 + (BETA2 * ALPHA2))        # inner order 2 term (for the main order 2 term)
    f12 = 0.0                           # inner linear term
    f02 = BETA2*( 1 + ALPHA2*BETA2 )    # inner independent term

    f21 = -2.0*ALPHA*BETA2              # same (for the main linear term)
    f11 = 0.0
    f01 = 0.0

    f20 = BETA4*ALPHA2                  # same (for the main independent term)
    f10 = 0.0
    f00 = 0.0

    C2 = 0

    r = a + b
    println("#first coding: deterministic, one realization")
    println("cascadas_fractal() ....... a: ", a, " b: ", b, " r= a + b : ",r)
    println("cascadas_fractal() ....... Beta: ", BETA, " Alpha: ", ALPHA)
    println("cascadas_fractal() ....... gi: ", gi, " gend: ", gend)
         
# Initializing arrays
# Array for the 3 initial values
    fi = zeros(1,3)
# Array for 9 initial values
    f = zeros(1,9)

# Generating the 3 initial values: s=1
    fi[1] = 1.0+(ALPHA2*BETA2) 
    fi[2] = 0.0;
    fi[3] = BETA2;

## 1st fractal row initialization - Inicializacion de la 1ra fila de fractal
    ss = 1
    estebias = convert(Int64, d/(3^ss))
    if VERBOSE == 1 println("d : ",d," estebias : ",estebias) end
    estestep = estebias

# Filling - Llenando fractal[1,i] 
    j = 1
    for i = 1:d
        if i <=estebias
	    fractal[1,i] = fi[j]
        elseif j<3^ss # si hemos llegado a f[3] estamos terminado de rellenar - if at f[3] we finished filling
            j = j+1
	    fractal[1,i] = fi[j]
            estebias = estebias + estestep
	end
    end

    r1 = r
    println(" Deterministic running, r1: ", r1)
    r1 = r1*r1 #square

    k=0

# No uso las dos primeras posiciones que corresponderían a las condiciones iniciales (g=0,1)

# Comenzamos calculando los 9 coeficientes de la segunda generación 
# (equivalente a una division del intervalo unidad en segmentos de 1/3^2=1/9 (s=2))
# 9 values for the second generation (s=2, 3^2=9)
# Initializing f[]
    f[1] = f22 * r * r;
    f[2] = f12;
    f[3] = f02;
    
    f[4] = f21 * r * r;
    f[5] = f11;
    f[6] = f01
    
    f[7] = f20 * r * r;
    f[8] = f10;
    f[9] = f00;

    g = gend
    
# Solo se calcula el fractal NO se necesita iterar sobre g como es el caso cuando se calcula la distribución
# Only for fractal calculations. The power law NEED repeated iterations till gend, step after step.     
# TOTAL number of points to be displayed. AQUI SE DEFINE LA DIMENSION(g)

    d = 3^g  #output vector dimension:  dimensión de la recta soporte de la generación final. Depende de g
    println("Dimension: d=3^g : ", d)
    l1 = zeros(1,d)   
    l0 = zeros(1,d)
    
    ss = 2
    estebias = convert(Int64, d/(3^ss))
    estestep = estebias
    #    	 if VERBOSE == 1 println("d : ",d," estebias : ",estebias) end

# Llenando l0 - Filling l0
    j = 1
    for i=1:d
        if i <=estebias
            l0[i] = f[j]
	    fractal[2,i] = f[j]
        elseif j<9 # si hemos llegado a f[9] estamos terminando de rellenar - if at f[9] we finished filling
            j = j+1
            l0[i] = f[j]
	    fractal[2,i] = f[j]
            estebias = estebias + estestep
        end
    end


#s # variable de generaciones - loop over generations
    for s = 3:g #Sub-lazo SOBRE GENERACIONES: Llegamos hasta g	- sub-loop over generations: going till g
        if VERBOSE == 1 println("... ... Sub-loop OVER GENERATIONS: in s :",s," final g: ",g," estestep : ",estestep) end
        order = 2 #el grado del polinomio decrece desde 2 hasta 0 y vuelve al valor 2 -> 0 - polynomial degree decreases from 2 to 0 and backs to 2->0
        m = 1
        bias2 = convert(Int64,  d/(3^s) )
        if VERBOSE == 1 println("Generation: ", s," bias2: ",bias2) end
        n = 0    #IMPORTANT
        bias = 1 #IMPORTANT
        if VERBOSE == 1 println("bias : ", bias," bias2 : ",bias2) end
        if VERBOSE == 1 println(" n : ",n," bias +  (bias2*n) : ",bias +  (bias2*n)) end
#### Lazo sobre i principal - loop over i #############################    
        flag = 1
        for i = 1:d # barremos toda la dimension del arreglo - over all the array dimension
            if i == bias +  (bias2*n)
                n = n + 1 #si alcanzamos la frontera de un subintervalo pasamos al otro coeficiente - if reaching an subinterval boundary goes to next coefficient 
                if VERBOSE == 1   println(" ... Subinterval boundary: moving to the next coefficient") end
            end
            
            if n == 10 # si llegamos a un valor de n fuera de rango (no puede exceder 9) - if we reach n of range (can't exceed 9)
                n = 1    # volvemos al principio - start again
                bias = i # y se asigna el valor del indice como bias de subdivision del segmento - and index is assigned to the bias of segment subdiv     
                order = order - 1 #se reduce el grado del polinomio una unidad - polynomial degree reduced by one
                
                if order == -1 order = 2 end #si se supera grado 0 se restablece grado 2 - if degree falls bellow 0 degree 2 is restated
            end
	    
            # se calcula el coeficiente dependiendo de la posición en el arreglo (i) y del segmento (n) - the coefficient value depending on its position in the array (i) and segment (n)
            if n == 1
                C2 = l0[i] #El mismo valor de la generación anterior en la posición i - same value as in previous generation at position i
                l1[i] =  C2*r*r
		fractal[s,i] =  l1[i] #filling fractals
            elseif n == 2 
                l1[i] = 0.0
		fractal[s,i] =  l1[i]
            elseif n == 3 
                l1[i] =  BETA2*C2*r*r #C2 tambien se usa aquí - C2 is also used here
		fractal[s,i] =  l1[i]
            elseif n == 4 
                l1[i] =  -order*ALPHA*BETA2*C2*r #y aquí
		fractal[s,i] =  l1[i]
            elseif n == 5 
                l1[i] =  0
		fractal[s,i] =  l1[i]
            elseif n == 6 
                l1[i] =  0
		fractal[s,i] =  l1[i]
            elseif n == 7 
                l1[i] =  BETA2*ALPHA2*l0[i] #El mismo valor de la generación anterior en la posición i (C0)- same value as in previous generation at position i (C0)
		fractal[s,i] =  l1[i]
            elseif n == 8 
                l1[i] =  0
		fractal[s,i] =  l1[i]
            elseif n == 9 
                l1[i] =  0
		fractal[s,i] =  l1[i]
            end
        end # fin barrido hasta d - end loop over d 
        #### Fin del lazo sobre i principal - Ends loop over main i #######################  
        for i=1:d  l0[i] = l1[i] end # updating l0

        if VERBOSE == 1    println("... ... LAZO INTERNO SOBRE GENERACIONES: saliendo s: ",s) end
        println("Generación: ", s," bias2: ",bias2)
    end # Fin barrido SOBRE s hasta g - End loop over s till g

    
    println("cascadas_fractal(): finished. exit ...")
    println(" ")
    
    return fractal # returns fractal array
    
end
