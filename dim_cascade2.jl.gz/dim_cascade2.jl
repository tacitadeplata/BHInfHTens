#Code and data from the article "Black hole information turbulence and the Hubble tension"
#Copyright (C) 2025  Juan Luis Cabrera Fernández

#This project is licensed under the terms of the Attribution-NonCommercial-ShareAlike 4.0 International - Creative Commons licence (CC BY-NC-SA 4.0). 
# https://creativecommons.org/licenses/by-nc-sa/4.0/deed.en
# JLCF: 22/01/2025 : This code builds the file dims_ReglaCascada_iter$n.txt 

using Printf

function dim_cascade()
# Definimos las reglas. Defining rules
    ab = "ab";
    abc = "abc";
    abcd = "abcd";

    n=27
    filename = "/Users/jlc/EnElaboracion/Cascading_ReservoirNN/prog/Susskind/dims_ReglaCascada_iter$n.txt"
    head = "grainsT, Dcg, MotifoverG, D"

    open(filename,"w") do io
        println(io,head)
    end

    D = zeros(Float64,n);#Dimension: contando cada motivo. D motif. Counting each motif
    Dcg = zeros(Float64,n);#Dimension course grainning: contando cada elemento: cada grano. Counting each element: each grain
    coverage = zeros(Float64,n);
    LengthDust = zeros(Float64,n);
    MotifoverG = zeros(Float64,n);
    coverage[1]=1;
    dust=[ab];#Motivo generador. Dos elementos (dos granos). Generator motif (two grains)
    countgrains = 0
    grainsT = zeros(Int64,n); # arreglo para almacenar el número de granos con cada generación. Array to store the number of grains in each generation
    dustt=[];
    lengthtmp=1;
    for j in 1:n
        countgrains = 0;
        for i in 1:length(dust)
            if dust[i] == ab;
                append!(dustt, [abcd]) #Concateno motivos para producir la próxima generación. Concatenating motifs to produce next generation. 
                countgrains += 2; #el motivo ab está compuesto por 2 granos. ab motif is composed by two grains.
            elseif dust[i] == abc
                append!(dustt, [abcd, abc])
                countgrains += 3;
            elseif dust[i] == abcd
                append!(dustt, [abcd, abc, ab])
                countgrains += 4;
            end
    end

    grainsT[j] = countgrains;# Se almacena el número total de granos en esta generación. Storing the total number of grains in this generation.
#    println("countgrains : ",countT[j] ) 
    dust = deepcopy(dustt); #El arreglo temporal se almacena en dust. the temporal array is stored in dust.
    dustt = []; #Se vacía el arreglo temporal. Emptying the temporal array. 
    LengthDust[j] = length(dust)# Número de motivos
    if j>1
        coverage[j] = LengthDust[j]/LengthDust[j-1]; #Coverage según Li Jin. Coverage accoring to Li Jin paper (not taken into account in our paper right now)
    end
    Dcg[j] = log( grainsT[j] ) / log(3^j) #Dimension course grainning

    println("n : ",j," length : ", length(dust), " F/3^n : ", length(dust)/3^j, "................... D : ", log(length(dust))/log(3^j) )
    println("n : ",j," coverage F: ", coverage[j] )
    println("n : ",j," N grains[j]: ", grainsT[j], " .................... Dcg : log( N grains )/log(3^j) ", Dcg[j] )

    D[j] = log(length(dust))/log(3^j) #Motif dimension
    MotifoverG[j] = length(dust)/grainsT[j];
    println("number of grains: ",grainsT[j]," number of motifs : ", length(dust)," proportion m/g : ", MotifoverG[j] );

    open(filename,"a") do io
    println(io, grainsT[j]," ", Dcg[j]," ", MotifoverG[j]," ", D[j])
    end    
end

end
