#Code and data from the article "Black hole information turbulence and the Hubble tension"
#Copyright (C) 2025  Juan Luis Cabrera Fernández

#This project is licensed under the terms of the Attribution-NonCommercial-ShareAlike 4.0 International - Creative Commons licence (CC BY-NC-SA 4.0). 
# https://creativecommons.org/licenses/by-nc-sa/4.0/deed.en
 
# Paper figure: only Y1


#using CSV, DataFrames, Plots, DelimitedFiles, 
using Interpolations
using LaTeXStrings
using Plots
using DelimitedFiles
using DataFrames
using Latexify
using CSV
using Statistics

function figHLCDM()#( modelname, dim, Y)

# Change if you want to plot the figure or save the error file
PLOTFIGS = 1
SAVEERRORS = 0

  plot_font = "Helvetica"
  default(fontfamily=plot_font, framestyle=:semi, xtickfont=font(10), ytickfont=font(10), guidefont=font(18), grid=false,xlims=(0,25) )

  notaA = string.("A") 
  notaB = string.("B") 
  notaC = string.("C") 
  notaD = string.("D") 
  notaE = string.("E") 
  notaF = string.("F") 
  notaG = string.("G") 
  notaH = string.("H") 


function relativeerror(ph,eph,pe,epe,p,y)
# Posterior error is estimated as the Root mean square deviation (RMSD) between the posterior and the real data

  ep =  sqrt( mean( (sqrt.(p) .- sqrt.(y)).^2) )# this is an scalar
#  println(" ep : ",ep)
#  println( "(eph/(2*ph)) : ", (eph/(2*ph)) )
#  println( " ep ./ p :  ", mean(ep ./ p))
  return  (eph/(2*ph)) .+ (0.5 .* mean(ep ./ p));
end



function bigY1(post, deltaDD, ph, pe)
    return sqrt.(mean(ph)*  mean(eachcol(post))   ) ./ (sqrt.(deltaDD)).^(1/2*mean(pe));
end

function bigY2(post, deltaDD, hp, he)
    return (mean(ph).^(1 /2*mean(pe))) *sqrt.(mean(eachcol(post))) ./ (sqrt.(deltaDD)).^(1/2*mean(pe));
end



#Reading data from the casdade generated with the motif rules
# Loading dimension data after 27 iterations
  filename = "./dims_ReglaCascada_iter27.txt" 
  df = CSV.read(filename, delim=' ', DataFrame,  header=1);

# Identifica cada dimension
  grainsT = df.grainsT;
  Dcg = df.Dcg;
  MotifoverG = df.MotifoverG;
  D = df.D;
  n = size(df)[1]

  nR=300000

########################### Data Dcg ############################################
  dd = "Dcg"
  println("Dimension : ",dd)
# Calculo de las diferencias en Dcg, Dcg differences
  dDcg = zeros(Float64,n-1)
  for i in 1:n-1
    dDcg[i] = Dcg[i+1] - Dcg[i]
  end
#Cascada directa D/dD = dD/Dinversa. Direct cascade D/dD = dD/Dinverse
  IdDD = Dcg[1:n-1] ./ dDcg[1:n-1]
#  println("El 1er elemento de IdDD diverge")
#  println("Poping out  1st element")
  popfirst!(IdDD)
  println("Now the IdDD SERIES RUNS FROM x=2")
# generamos x con la misma longuitud que IdDD. x with same length than IdDD
  xdDD = collect(2:1:size(IdDD)[1]+1);
  ydDD = IdDD.^2;

#Loads summary and posterior info from Turing fitting. 
  mC="LCDM"
  Cname="chainLCDM"
  mY="Y1"
  println("Esquema : ",mY)
  input1 = "./Turing/data/LCDM/summarystats-$Cname-$nR$mY.jls"
  input2= "./Turing/data/LCDM/mean-posterior$mC-$Cname-$nR$mY.csv"
  posteriorM = readdlm(input2, ',', Float64)
  df = CSV.read(input1, delim=',', DataFrame,header=1)
  ph = df.mean[2];
  pe = df.mean[3];
  eph = df.std[2];   epe = df.std[3];  

  println(" ")
  println(" ph ", ph, " eph ", eph, " pe ", pe, " epe ", epe)
 
  xdDDlong = collect(-10:1:size(IdDD)[1]+1);
  p11 = scatter(xdDD, sqrt.(ydDD); label="", color=1, legend=:false,tick_direction=:out,xlimits=(0,27), shape=:+, markersize = 5) 
        Plots.plot!(xdDD,sqrt.(posteriorM); label="", color=:red , grid=false, size=(400,400),linewidth=2)
        Plots.ylabel!(L"\left(\dfrac{\Delta D_{cg}}{D_{cg}}\right)_{I}")
        Plots.xlabel!(" ")
        Plots.yticks!([0:2200:2200;], ["0", "2200"])
        annotate!(5, 2200, Plots.text(notaA,:right, 22, "Helvetica Bold")) 

        bigYD = sqrt.(ph.*posteriorM) ./ (sqrt.(ydDD)).^(1 ./2*pe);

# Extrapolo la función inversa. Extrapolating the inverse function
#Native Interpolations.jl doesn't provide built-in confidence intervals

          ribigYD = reverse(inv.(bigYD))
          xx=ribigYD[:,1]
          itp = Interpolations.interpolate(xx, BSpline(Quadratic(Periodic(OnCell()))   ))
          etp = Interpolations.extrapolate( itp, Interpolations.Line() ) #Line - linear extrapolation
          println(1 ./etp[26])
          h0 = [ 1 ./etp[26]]

          p12 =  Plots.scatter(2:1:26,reverse(1 ./etp[1:25] ) ,size=(300,300),legends=:none,color=1, shape=:+, markersize = 5)
              Plots.plot!(xdDD,bigYD,tick_direction=:out,color=:red,xlims=(0,27),linewidth=2)      
              Plots.scatter!([1], [h0] )
              Plots.ylabel!(L"\Upsilon(z)")
              Plots.yaxis!(minorticks=0)

              asymp = string.(round.(1/etp[26]; digits=2))
      annotate!(-1, 1/etp[26], Plots.text(asymp, :red, :right, 14))
      annotate!(25, 68, Plots.text(notaB,:right, 22, "Helvetica Bold")) 
              Plots.yticks!([50:20:70;], ["50", "70"])
              Plots.xticks!([0:5:25;], ["0","5","10","15","20","25"])

  ELCDMDcgY1 = relativeerror(ph,eph,pe,epe, posteriorM, ydDD)*h0
  println("ELCDMDcgY1 : ", ELCDMDcgY1)
#          display(pYD)
#          println("El elemento 26 a tau=1 : ", 1 ./etp[26])

#          println("showing pYD")
########################### Data D motif  ############################################
# Diferencias sucesivas -  D (motif) -  Differences 
  DiffD = zeros(Float64,n-1)
  nDiff = length(DiffD)
  for i in 1:nDiff
    DiffD[i] = D[i+1] - D[i]
  end
# Storing Inverse of derivative of Dmotif over Dmotif: IdDDmotif
  IdDDmotifs = D[1:nDiff] ./ DiffD[1:nDiff];
  popfirst!(IdDDmotifs)
  println("Now the IdDDmotifs SERIES RUNS FROM x=2")
  println( size(IdDDmotifs)[1] )
  xD = collect(2:1:size(IdDDmotifs)[1]+1);
  yD = IdDDmotifs.^2;


  mC="LCDM"
  Cname="chainmotifLCDM"
  mY="Y1"
  println("Esquema : ",mY)
  input1 = "./Turing/data/LCDM/summarystats-$Cname-$nR$mY.jls"
  input2= "./Turing/data/LCDM/mean-posterior$mC-$Cname-$nR$mY.csv"
  posteriorM = readdlm(input2, ',', Float64)
  df = CSV.read(input1, delim=',', DataFrame,header=1)
  ph = df.mean[2]
  pe = df.mean[3]
  eph = df.std[2];   epe = df.std[3];  

  println(" ")

# Posterior error is estimated as the sqrt of the square of the distance between the posterior and the real data

  p21 = Plots.scatter(xD, sqrt.(yD ); label="", color=1, legend=:false,tick_direction=:out, shape=:+, markersize = 5)
        Plots.plot!(xD,sqrt.(posteriorM); label="", color=:red , grid=false,size=(400,400), xlimits=(0,27),linewidth=2)      
        Plots.ylabel!(L"\left(\dfrac{\Delta D_m}{D_m}\right)_{I}")
  Plots.xlabel!(L"\tau")
        Plots.yticks!([200:600:800;], ["200", "800"])#,title="pHLCDM3")
        annotate!(5, 850, Plots.text(notaC,:right, 22, "Helvetica Bold")) 
#  display(pHLCDM3)

# Extrapolo la función inversa. Extrapolating the inverse function
  bigYmotif = sqrt.(ph*posteriorM) ./ (sqrt.(yD)).^(1/2*pe);
  ribigYmotif = reverse(inv.(bigYmotif))
  xx=ribigYmotif[:,1]

  itp = Interpolations.interpolate(xx, BSpline(Quadratic(Periodic(OnCell()))   ))
  etp = Interpolations.extrapolate( itp, Interpolations.Line() ) #Line - linear extrapolation
  println(1 ./etp[26])
  h0 = [ 1 ./etp[26]]
  p22 = Plots.scatter(2:1:26,reverse(1 ./etp[1:25] ) ,size=(300,300),legends=:none,color=1, xlimits=(0,27), shape=:+, markersize = 5)
        Plots.plot!(xD,bigYmotif,tick_direction=:out,color=:red,linewidth=2)
        Plots.scatter!([1], [h0] )

  Plots.ylabel!(L"\Upsilon(z)")
  Plots.xlabel!(L"\tau")
  xaxis!(minorticks=5)
  asymp = string.(round.(1 ./etp[26]; digits=2))
  annotate!(-1, 1 ./etp[26], Plots.text(asymp, :red, :right, 14))
  annotate!(25, 68, Plots.text(notaD,:right, 22, "Helvetica Bold")) 
  Plots.yticks!([45:20:65;], ["45", "65"])

#  display(pMot1)
  println("El elemento 26 a tau=1 : ", h0)

  ELCDMDmY1 = relativeerror(ph,eph,pe,epe, posteriorM, yD)*h0
  println("ELCDMDmY1 : ", ELCDMDmY1)

################################################################
if PLOTFIGS == 1
  savefig("./SI_fig12Y1.png")
end

head=  ["ELCDMDcgY1", "ELCDMDmY1",   "ELCDMDcgY2", "ELCDMDmY2"]
result = [   ELCDMDcgY1 ELCDMDmY1   ELCDMDcgY2 ELCDMDmY2 ]
df = DataFrame(result,head)
if SAVEERRORS == 1
  output="./Turing/ErrorPropagadoHLCDM.csv"
  CSV.write(output, df)
  println("Error propagation stored in ", output)
end

print("SALIENDO")
end
